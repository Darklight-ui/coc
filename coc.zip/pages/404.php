<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Not Found | Clay Option Concepts</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }
        
        :root {
            --primary: #3b82f6;
            --accent: #10b981;
            --surface: #ffffff;
            --text-primary: #1f2937;
            --border: #e5e7eb;
        }
        
        body {
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .electric-pulse {
            animation: pulse 2s infinite;
        }
        
        .floating {
            animation: floating 3s ease-in-out infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }
        
        @keyframes floating {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        
        .circuit-line {
            stroke-dasharray: 10;
            stroke-dashoffset: 20;
            animation: dash 20s linear infinite;
        }
        
        @keyframes dash {
            to {
                stroke-dashoffset: 1000;
            }
        }
    </style>
</head>
<body>
    <div class="relative w-full min-h-screen overflow-hidden">
        <!-- Background Circuit Pattern -->
        <div class="absolute inset-0 opacity-5">
            <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
                <defs>
                    <pattern id="circuit" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
                        <path d="M20,20 L80,20 M80,20 L80,80 M80,80 L20,80 M20,80 L20,20" 
                              stroke="var(--primary)" stroke-width="1" fill="none"/>
                        <circle cx="20" cy="20" r="2" fill="var(--primary)"/>
                        <circle cx="80" cy="20" r="2" fill="var(--primary)"/>
                        <circle cx="80" cy="80" r="2" fill="var(--primary)"/>
                        <circle cx="20" cy="80" r="2" fill="var(--primary)"/>
                        <path d="M50,50 L70,30 M30,50 L50,30" stroke="var(--accent)" stroke-width="1"/>
                    </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#circuit)"/>
            </svg>
        </div>

        <!-- Battery Icons Floating -->
        <div class="absolute top-10 left-10 opacity-10 floating" style="animation-delay: 0s;">
            🔋
        </div>
        <div class="absolute top-20 right-20 opacity-10 floating" style="animation-delay: 0.5s;">
            ⚡
        </div>
        <div class="absolute bottom-20 left-20 opacity-10 floating" style="animation-delay: 1s;">
            🔧
        </div>

        <div class="relative z-10 container mx-auto px-4 py-16">
            <div class="max-w-4xl mx-auto">
                <!-- Logo -->
                <div class="flex justify-center mb-8">
                    <a href="./" class="flex items-center gap-3">
                        <div class="bg-white p-3 rounded-xl shadow-lg">
                            <div class="w-12 h-12 bg-gradient-to-r from-blue-500 to-emerald-400 rounded-lg flex items-center justify-center">
                                <span class="text-2xl font-bold text-white">CO</span>
                            </div>
                        </div>
                        <div>
                            <h1 class="text-2xl font-bold text-gray-800">Clay Option Concepts</h1>
                            <p class="text-gray-600">Power Solutions & Energy Innovation</p>
                        </div>
                    </a>
                </div>

                <!-- Main Content -->
                <div class="text-center">
                    <!-- Animated 404 -->
                    <div class="relative mb-8">
                        <div class="text-9xl font-bold text-gray-800 mb-4">
                            <span class="relative inline-block">
                                <span class="text-blue-500">4</span>
                                <div class="absolute -top-4 -right-4">
                                    <div class="w-12 h-12 bg-gradient-to-r from-emerald-400 to-blue-500 rounded-full flex items-center justify-center electric-pulse">
                                        <div class="w-6 h-6 bg-white rounded-full"></div>
                                    </div>
                                </div>
                            </span>
                            <span class="text-gray-300 mx-4">•</span>
                            <span class="relative inline-block">
                                <span class="text-emerald-500">0</span>
                                <div class="absolute -bottom-4 -left-4">
                                    <div class="w-10 h-10 bg-gradient-to-r from-blue-500 to-emerald-400 rounded-full flex items-center justify-center">
                                        <div class="w-4 h-4 bg-white rounded-full"></div>
                                    </div>
                                </div>
                            </span>
                            <span class="text-gray-300 mx-4">•</span>
                            <span class="text-blue-400">4</span>
                        </div>
                        
                        <!-- Circuit Connection -->
                        <div class="max-w-md mx-auto mb-8">
                            <svg width="100%" height="20" xmlns="http://www.w3.org/2000/svg">
                                <path d="M0,10 Q100,0 200,10 T400,10" 
                                      stroke="#e5e7eb" 
                                      stroke-width="2" 
                                      fill="none"/>
                                <circle cx="100" cy="10" r="3" fill="#10b981"/>
                                <circle cx="300" cy="10" r="3" fill="#3b82f6"/>
                            </svg>
                        </div>
                    </div>

                    <!-- Message -->
                    <h2 class="text-4xl font-bold text-gray-800 mb-4">
                        Connection Lost
                    </h2>
                    <p class="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
                        The page you're looking for seems to have short-circuited. Don't worry - 
                        we're redirecting you back to our power grid.
                    </p>

                    <!-- Stats -->
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 max-w-2xl mx-auto">
                        <div class="bg-white/80 backdrop-blur-sm p-6 rounded-xl border border-gray-200 shadow-sm">
                            <div class="text-3xl font-bold text-blue-500 mb-2">404</div>
                            <div class="text-gray-600">Error Code</div>
                        </div>
                        <div class="bg-white/80 backdrop-blur-sm p-6 rounded-xl border border-gray-200 shadow-sm">
                            <div class="text-3xl font-bold text-emerald-500 mb-2">100%</div>
                            <div class="text-gray-600">Working Pages</div>
                        </div>
                        <div class="bg-white/80 backdrop-blur-sm p-6 rounded-xl border border-gray-200 shadow-sm">
                            <div class="text-3xl font-bold text-blue-400 mb-2">24/7</div>
                            <div class="text-gray-600">Support Available</div>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div class="flex flex-col sm:flex-row gap-4 justify-center mb-12">
                        <a href="../"
                           class="inline-flex items-center justify-center px-8 py-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white font-medium rounded-lg hover:from-blue-600 hover:to-blue-700 transition-all duration-300 shadow-lg hover:shadow-xl">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
                            </svg>
                            Return to Homepage
                        </a>
                        <a href="Contact-us"
                           class="inline-flex items-center justify-center px-8 py-3 bg-white text-gray-800 font-medium rounded-lg border-2 border-gray-300 hover:border-blue-500 hover:bg-blue-50 transition-all duration-300 shadow-sm hover:shadow">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                            </svg>
                            Contact Support
                        </a>
                    </div>

                    <!-- Search Box -->
                    <div class="max-w-xl mx-auto mb-12">
                        <div class="relative">
                            <input type="text" 
                                   placeholder="Search for products, batteries, or solutions..."
                                   class="w-full px-6 py-4 pl-14 bg-white/90 backdrop-blur-sm border-2 border-gray-300 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all duration-300 shadow-sm">
                            <div class="absolute left-4 top-1/2 transform -translate-y-1/2">
                                <svg class="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                                </svg>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Links -->
                    <div class="border-t border-gray-200 pt-8">
                        <h3 class="text-lg font-semibold text-gray-700 mb-4">Popular Pages</h3>
                        <div class="flex flex-wrap justify-center gap-4">
                            <a href="Lithium-Battery" class="text-blue-600 hover:text-blue-800 transition-colors">Lithium Batteries</a>
                            <span class="text-gray-300">•</span>
                            <a href="Inverters" class="text-blue-600 hover:text-blue-800 transition-colors">Inverters</a>
                            <span class="text-gray-300">•</span>
                            <a href="gel-batteries.html" class="text-blue-600 hover:text-blue-800 transition-colors">GEL Batteries</a>
                            <span class="text-gray-300">•</span>
                            <a href="Contact-us" class="text-blue-600 hover:text-blue-800 transition-colors">Contact Us</a>
                        </div>
                    </div>
                </div>

                <!-- Footer -->
                <div class="mt-16 pt-8 border-t border-gray-200 text-center text-gray-500">
                    <p>© 2024 Clay Option Concepts. All rights reserved.</p>
                    <p class="text-sm mt-2">Powering innovation with reliable energy solutions</p>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Add some interactive elements
        document.addEventListener('DOMContentLoaded', function() {
            // Animate battery icons on hover
            const batteryIcons = document.querySelectorAll('.floating');
            batteryIcons.forEach(icon => {
                icon.addEventListener('mouseenter', function() {
                    this.style.transform = 'scale(1.2)';
                    this.style.opacity = '0.3';
                });
                icon.addEventListener('mouseleave', function() {
                    this.style.transform = '';
                    this.style.opacity = '0.1';
                });
            });

            // Search functionality
            const searchInput = document.querySelector('input[type="text"]');
            searchInput?.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    alert('Search functionality would redirect to search results page');
                }
            });

            // Pulsing effect for 404 numbers
            const numbers = document.querySelectorAll('.text-9xl span');
            numbers.forEach((num, index) => {
                num.style.animation = `pulse ${2 + index * 0.5}s infinite`;
            });
        });
    </script>
</body>
</html>